#/data/data/com.termux/files/usr/bin/bash
#/data/data/com.termux/files/usr/bin/sh
#/bin/bash
#/bin/sh

cd src
apt install -y nodejs
node app.js
